package com.greatlearning.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEmployeeManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
